@extends('Layout')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="{{ asset('public/css/Custom.css') }}">
</head>
<body>
<h1>	Create Supplier Account</h1>
	<form action="suppliers" method="post">
		@csrf
			<div class="forms">
		<table>
			<tr><th>Name</th><td><input type="text" name="name" required=" " placeholder="Enter customer Name"></td>
			 </tr>
			 <tr><th>Email ID</th><td><input type="email" name="email" required=" " placeholder="Enter customer Email ID"></td>
			 </tr>
			<tr><th>Address</th><td><input type="text" name="address" required=" " placeholder="Enter customer Name"></td>
			 </tr>
			 <tr><th>Phone Nummber</th><td><input type="text" name="phoneno" required=" " placeholder="Enter customer Contect No"></td>
			 </tr>
			 
			 <tr>
			<th>City</th><td><select name="city">
				<option>Patna</option>
				<option>jhanabad</option>
				<option>Arwal</option>
				<option>Ara</option>
				<option>Gaya</option>
				<option>Aurangabad</option>
			</select>
		</td>
	          </tr>
	           <tr>
			<th>State</th><td ><select name="state">
				<option>Bihar</option>
				<option>JharKhand</option>
				<option>Utar Pradesh</option>
				<option>Madhay Pradesh</option>
				<option>Maharashtra</option>
				<option>Goa</option>
			</select>
		</td>
	          </tr>
	          
	         <tr>
			<th>Contry</th><td ><select name="contry">
				<option>India</option>
				<option>England</option>contry
				<option>Nepal</option>
				<option>America</option>
				<option>Sri Lanka</option>
				<option>Rush</option>
			</select>
			</td>
	          </tr>
	          <tr><th>Suppplier Id</th><td><input type="text" name="suppliers" required="" placeholder="Entry Your Suppplier ID">
			 <tr><td style="float: right;"><button>Create Customer</button></td></tr>
		</table>

</div>
	</form>

</body>
</html>
@stop