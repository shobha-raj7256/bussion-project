@extends('Layout')
@section('content')
<h1>users</h1>
<h2>wellocome{{Session('data')['name']}</h2>}

@stop