@extends('Layout')
@section('content')
<style type="text/css">
\*{
   
  margin: 0px;
  padding: 0px;

}
.table{
	width: 90%;
	align-content: center;
	margin: 50px;
	margin-left: 75px;
	height: 100%;
	background-color: grey;
	color:white;
	line-height: 30px;
	text-align: center;
	font-size: 20px;
}

table, th, td {
  border: 1px solid white;
  border-collapse: collapse;

}
th, td {
  padding: 5px;
  text-align: left;    
}
h2{
	text-transform: capitalize;
	text-align: center;
	text-shadow: 10px 10px 10px 10 grey;
background-color:  black;
	color:white;
	height: 80px;
	line-height: 80px;
}
</style>
<h2>Suppliers Page</h2>
@if(Session::get('status'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
  {{Session::get('status')}}
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
@endif
<div class="table">
<table broder >
	<tr>
		<th>ID </th>
		<th>Name </th>
	<th>Email Id </th>
	<th>Address </th>
	<th>Contect No</th>
	<th>State</th>
	<th>City </th>
 <th>Contry  </th>
  <th>Suppliers </th>
 <th th colspan="2">Opreation</th>
</tr>
@foreach($data1 as $iteam)
<tr>
	<td>{{ $iteam->id}}</td>
<td>{{ $iteam->name}}</td>
<td>{{ $iteam->email}}</td>
<td>{{ $iteam->address}}
<td>{{ $iteam->phoneno}}</td>
<td>{{ $iteam->city}}</td>
<td>{{ $iteam->state}}</td>
<td>{{ $iteam->contry}}</td>
<td>{{ $iteam->suppliers}}</td>
<td><a href="supdelete/{{ $iteam->id }}">Delete</a></td>

<td><a href="supedit/{{ $iteam->id }}">Edit</a></td>
</tr>
@endforeach
</table>
</div>
@stop