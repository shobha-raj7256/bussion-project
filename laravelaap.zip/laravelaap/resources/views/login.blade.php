@extends('Layout')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="{{ asset('public/css/custom.css') }}">
</head>
<body>
	<h1>login Users</h1>
	<div class="forml">
		<form action="login" method="post">
			@csrf
		<table>
			
			<tr><th>Email</th><td><input type="email"  name="email" placeholder="Enter your Email Id"  required=" " /></td>
			</tr>
			
			<tr><th>Password</th><td><input type="password"  name="password" placeholder="Enter your password" required=" " /></td>
			</tr>
			<tr> <td><button type="submit" style="float:right;">Login</button></td>
			</tr>
		</table>
		</form>
	</div>

</body>
</html>

@stop