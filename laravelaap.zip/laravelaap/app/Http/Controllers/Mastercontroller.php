<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use  App\Users ;
use App\Suppliers;
use App\customer;
use Session;
use Illuminate\Support\Facades\Auth;

class Mastercontroller extends Controller
{
    function Regester(Request $req ){
    
   //print_r($req->input());
    $users=new Users;
    $users->name= $req->name ;
    $users->email= $req->email;   
     $users->phoneno= $req->phoneno;
     $users->password=  $req->password;
    $users->save();
    $req->Session()->put('Users',$req->name);
    return redirect('login');
    }
function userdata(){
    $userview=Users::all();
      return view('loginusers',["userview"=>$userview]);
    
}
 function login(Request $req){
   
  $Users= Users::where('email',$req->email)->get();


  if(($Users[0]->password)==$req->password){
    $req->Session()->put('Users',$Users[0]->name);

   $req->Session()->put('Users',$req->input());
    return redirect('loginusers');


   
    }


    }
    function customer(Request $req){
    //print_r($req->input());
    	$cus=new customer ;
    	$cus->name= $req->name;
    	$cus->email= $req->email;
    	$cus->address= $req->address;
    	$cus->phoneno= $req->phoneno;
    	$cus->city= $req->city;
    	$cus->state= $req->state;
    	$cus->contry= $req->contry;
  $customer=$cus->save();
 Session::flash('status','Your Data inserted Sucessfully');
      return redirect('list');
    }
    function suppliers (Request $req){
    $sub = new Suppliers;
    $sub->name= $req->name;
    	$sub->email= $req->email;
    	$sub->address= $req->address;
    	$sub->phoneno= $req->phoneno;
    	$sub->city= $req->city;
    	$sub->state= $req->state;
    	$sub->contry= $req->contry;
    	$sub->suppliers= $req->suppliers;
$sub->save();
    Session::flash('status','Your Data inserted Sucessfully');
      return redirect('slist');
    }
     function list(){
     	$data=Customer::all();
   return view('list',["data"=>$data]);

     }
     function slist(){
     	$data1=Suppliers::all();
     	return view('supplierslist',["data1"=>$data1]);
     }
     function cumdelete($id){
     	

     	customer::find($id)->delete();
     	Session::flash('status','Your Data delete Sucessfully');
     	return redirect('list');
     }
     function supdelete($id){
     	

     	$del1= Suppliers::find($id)->delete();
     	Session::flash('status','Your Data delete Sucessfully');
     	return redirect('slist');
     }
      function cumedit($id){
      	 $data =customer::find($id);
      	return view('cumedit',['data'=>$data]);
      }
      function supedit($id){
      	 $data1 =Suppliers::find($id);
      	return view('supedit',['data1'=>$data1]);
      }

      function update(Request $req ){
 $cus=customer::find($req->id);
    $cus->name= $req->name;
      $cus->email= $req->email;
      $cus->address= $req->address;
      $cus->phoneno= $req->phoneno;
      $cus->city= $req->city;
      $cus->state= $req->state;
      $cus->contry= $req->contry;
$cus->save();
$req->Session()->flash('status','Updated successfully');
return redirect('list');
  
    }
     function supupdate(Request $req ,$id){

    $cus=Suppliers::find($req->id);
    $cus->name= $req->name;
      $cus->email= $req->email;
      $cus->address= $req->address;
      $cus->phoneno= $req->phoneno;
      $cus->city= $req->city;
      $cus->state= $req->state;
      $cus->contry= $req->contry;

$cus->save();

$req->Session()->flash('status','Updated successfully');
return redirect('slist');
     }
public function logout(Request $request) {
  
  Auth::logout();
  return redirect('login');
}
     }
