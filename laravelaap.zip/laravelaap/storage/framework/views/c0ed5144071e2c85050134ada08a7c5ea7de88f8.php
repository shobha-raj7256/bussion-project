
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body {
  background-image: url('<?php echo e(asset('public/images/img2.jpg')); ?>');
   background-repeat: repeat;
}
h1{
	text-align: center;
	margin-top: 200px;
	margin-left: 250px;
	margin-right: 200px;
	margin-bottom: 100px;
	color: #17A589;

}
.show{
	text-align: center;
	height: 100px;
	width:600px;
	
	padding: 5px;
	margin-left: 400px;
	line-height: 40px;
	display: inline-block;
}
#page{
	text-decoration: none;
	background-color: #117864 ;
	font-size: 24px;
	color: white;
	padding: 15px;
	border-radius: 10px;
	border: 3px solid #A2D9CE;
font-weight: bold;
	box-shadow: 2px 2px 2px 2px grey;
	
}
#page a:hover{
	color: black;
	background-color: white;
}

	</style>


	
</head>
<body>
	<h1> Wellcome To Laravel App</h1>
	<div class="show">
<a  id="page" href="regester">Regester here</a>
<a  id="page" href="login" >Login here</a>
</div>
</body>
</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelaap\resources\views/Home.blade.php ENDPATH**/ ?>