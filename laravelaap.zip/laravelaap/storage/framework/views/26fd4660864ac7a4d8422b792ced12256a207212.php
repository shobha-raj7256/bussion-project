
<?php $__env->startSection('content'); ?>
<style type="text/css">
\*{
   
  margin: 0px;
  padding: 0px;

}
.table{
	width: 70%;
	align-content: center;
	margin: 50px;
	margin-left: 200px;
	height: 100%;
	background-color: grey;
	color:white;
	line-height: 30px;
	text-align: center;
	font-size: 20px;
}

table, th, td {
  border: 1px solid white;
  border-collapse: collapse;

}
th, td {
  padding: 5px;
  text-align: left;    
}
h2{
	text-transform: capitalize;
	text-align: center;
	text-shadow: 10px 10px 10px 10 grey;
background-color:  black;
	color:white;
	height: 80px;
	line-height: 80px;
}
</style>
<h2>Customer Page</h2>
<?php if(Session::get('status')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php echo e(Session::get('status')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<div class="table">
<table broder >
	<tr>
		<th>ID </th>
		<th>Name </th>
	<th>Email Id </th>
	<th>Address </th>
	<th>Contect No</th>
	<th>State</th>
	<th>City </th>
 <th>Contry  </th>
 <th th colspan="2">Opreation</th>
</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($iteam->id); ?></td>
<td><?php echo e($iteam->name); ?></td>
<td><?php echo e($iteam->email); ?></td>
<td><?php echo e($iteam->address); ?>

<td><?php echo e($iteam->phoneno); ?></td>
<td><?php echo e($iteam->city); ?></td>
<td><?php echo e($iteam->state); ?></td>
<td><?php echo e($iteam->contry); ?></td>
<td><a href="cumdelete/<?php echo e($iteam->id); ?>">Delete</a></td>
<td><a href="cumedit/<?php echo e($iteam->id); ?>">Edit</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelaap\resources\views/list.blade.php ENDPATH**/ ?>