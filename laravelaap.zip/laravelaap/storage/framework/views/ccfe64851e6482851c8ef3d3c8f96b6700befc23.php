
<?php $__env->startSection('content'); ?>
<h1>users</h1>
<h2>wellocome{{Session('data')['name']}</h2>}

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelaap\resources\views/profile.blade.php ENDPATH**/ ?>