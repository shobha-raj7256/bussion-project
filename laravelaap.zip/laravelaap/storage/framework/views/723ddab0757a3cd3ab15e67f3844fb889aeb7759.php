
<?php $__env->startSection('content'); ?>
<style type="text/css">
*{
	margin: 0px;
	padding: 0px;
}
	.user{
	
		width: 100%;
		height: 600px;
		background-image: linear-gradient(to right bottom, #517ec2, #278db0, #509395, #799486, #92948e);
	}
	#show{
		height: 50px;
		
		color: white;
		text-transform: capitalize;
		text-shadow: 2px 2px black;
		text-align: center;
		line-height: 50px;
	}
	h6{
		text-transform: capitalize;
		text-decoration: none;
		
	}
	h6 a{
		margin: 50px;
		font-size: 32px;
		color: pink;
	}
	h6 a:hover{
		text-decoration: none;
		color:#E74C3C ;
	}
</style>
<div class="user">
<h6>
<a href="logout">logout</a><h6>
<h1 id="show">Profile Users</h1>
<h2 id="show">Wellcome</h2></br>
<h5 id="show"><?php echo e(Session('Users')['email']); ?></h5>

<br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelaap\resources\views/loginusers.blade.php ENDPATH**/ ?>