
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/custom.css')); ?>">
</head>
<body>
	<h1>login Users</h1>
	<div class="forml">
		<form action="login" method="post">
			<?php echo csrf_field(); ?>
		<table>
			
			<tr><th>Email</th><td><input type="email"  name="email" placeholder="Enter your Email Id"  required=" " /></td>
			</tr>
			
			<tr><th>Password</th><td><input type="password"  name="password" placeholder="Enter your password" required=" " /></td>
			</tr>
			<tr> <td><button type="submit" style="float:right;">Login</button></td>
			</tr>
		</table>
		</form>
	</div>

</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelaap\resources\views/login.blade.php ENDPATH**/ ?>