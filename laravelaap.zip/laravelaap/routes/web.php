<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/
Route::get('/', function () {
    return view('Home');
});

Route::get('list',"Mastercontroller@list");
Route::get('slist',"Mastercontroller@slist");
Route::view('regester',"regester");
Route::view('login',"login");
Route::post('/regester',"Mastercontroller@Regester");
Route::post('/login',"Mastercontroller@login");
Route::view('customer','customer');
Route::Post('/customer',"Mastercontroller@customer");
Route::view('suppliers','suppliers');
Route::Post('/suppliers',"Mastercontroller@suppliers");
Route::get('cumdelete/{id}',"Mastercontroller@cumdelete");
Route::get('supdelete/{id}',"Mastercontroller@supdelete");
Route::get('cumedit/{id}',"Mastercontroller@cumedit");
Route::get('supedit/{id}',"Mastercontroller@supedit");
Route::post('cumedit/{id}',"Mastercontroller@update");
Route::post('supedit/{id}',"Mastercontroller@supupdate");
Route::get('loginusers',"Mastercontroller@userdata");

Route::get('loginusers',"Mastercontroller@userdata");
Route::get('logout', function () {
	session()->forget('users');
    return view('login');
});